//
//  DetailsViewController.swift
//  Rides
//
//  Created by TEKKR AGRI ORGANICS PRIVATE LIMITED on 02/02/23.
//

import UIKit
private struct Constants {
    static let SectionSpacing: CGFloat = 10
    static let NumberOfCellsInARow: CGFloat = 2
}
class DetailsViewController: UIViewController,UICollectionViewDataSource, UICollectionViewDelegate {
    @IBOutlet weak private var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    let emission_value = 5000
    private var currentPage = 0
    
    @IBOutlet weak var vinLbl: UILabel!
    @IBOutlet weak var modelLbl: UILabel!
    @IBOutlet weak var colorLbl: UILabel!
    @IBOutlet weak var carTypeLbl: UILabel!
    var photoIndex: Int?
    var page: Int?
    var rideDetails:RideModel?
    var vinStr, modelStr, colorStr, carTypeStr : String!
    override func viewDidLoad() {
        super.viewDidLoad()
        pageControl.numberOfPages = 2
        configureUI()
    }
    // MARK: - UI Setup
    private func configureUI() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.sectionInset = UIEdgeInsets(top: Constants.SectionSpacing,
                                                             left: Constants.SectionSpacing,
                                                             bottom: Constants.SectionSpacing,
                                                             right: Constants.SectionSpacing)
        collectionViewFlowLayout.itemSize = CustomCollectionViewCell.getSize()
        collectionViewFlowLayout.minimumLineSpacing = Constants.SectionSpacing
        collectionViewFlowLayout.minimumInteritemSpacing = Constants.SectionSpacing
        collectionViewFlowLayout.scrollDirection = .horizontal
        
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        
        collectionView.collectionViewLayout = collectionViewFlowLayout
        collectionView.decelerationRate = UIScrollView.DecelerationRate.fast
        collectionView.register(UINib(nibName: CustomCollectionViewCell.reuseIdentifier(),
                                      bundle: nil),
                                forCellWithReuseIdentifier: CustomCollectionViewCell.reuseIdentifier())
        collectionView.register(UINib(nibName: EmissionCollectionViewCell.reuseIdentifier(),
                                      bundle: nil),
                                forCellWithReuseIdentifier: EmissionCollectionViewCell.reuseIdentifier())
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    @IBAction func backAction(_ sender: UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
    // MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.item == 0
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CustomCollectionViewCell.reuseIdentifier(), for: indexPath) as! CustomCollectionViewCell
            cell.vinLbl.text = rideDetails?.vin ?? ""
            cell.modelLbl.text = rideDetails?.make_and_model ?? ""
            cell.colorLbl.text = rideDetails?.color ?? ""
            cell.carTypeLbl.text = rideDetails?.car_type ?? ""
            
            return cell
        }
        else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: EmissionCollectionViewCell.reuseIdentifier(), for: indexPath) as! EmissionCollectionViewCell
            let kilometers = Int(rideDetails?.kilometrage ?? 0)
            var carbon_value : Int = 0
            if kilometers <= emission_value
            {
              carbon_value = kilometers*1
            }
            else{
                let value = Int(kilometers - emission_value)
                let emitedValue = Float(value)*1.5
                carbon_value = emission_value + Int(emitedValue)
            }
            cell.kilometerLbl.text = "Total kilometrage : \(rideDetails?.kilometrage ?? 0) km"
            cell.carbonLbl.text = "Emitted carbon : \(carbon_value) Units"
            print(rideDetails?.kilometrage ?? "")
            return cell
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.width , height: 165)
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        self.pageControl.currentPage = indexPath.item
    }
}
