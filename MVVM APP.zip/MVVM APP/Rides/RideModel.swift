//
//  RideModel.swift
//  Rides
//
//  Created by TEKKR AGRI ORGANICS PRIVATE LIMITED on 02/02/23.
//

import Foundation
struct RideModel: Codable {
    
    var uid          : String?
    var vin   : String?
    var make_and_model   : String?
    var color : String?
    var transmission          : String?
    var drive_type   : String?
    var fuel_type   : String?
    var car_type : String?
    var car_options          : [String]?
    var specs   : [String]?
    var doors   : Int?
    var mileage : Int?
    var kilometrage : Int?
    var license_plate : String?
  
}
