//
//  ViewController.swift
//  Rides
//
//  Created by TEKKR AGRI ORGANICS PRIVATE LIMITED on 02/02/23.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource {


    @IBOutlet weak var submitBtn: UIButton!
    @IBOutlet weak var txtFld: UITextField!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var sortView: UIView!

    var ridesListArr:[RideModel] = []
    var sortType:String = "vin"
    @IBOutlet weak var vehicleTblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        submitBtn.layer.cornerRadius = 6
        submitBtn.clipsToBounds = true
        txtFld.delegate = self
        vehicleTblView.delegate = self
        vehicleTblView.dataSource = self
    }
    @IBAction func sortAction(sender: UISegmentedControl)
    {
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
          sortType = "vin"
            vehicleTblView.reloadData()
        case 1:
            sortType = "car Type"
            vehicleTblView.reloadData()
        default:
            break;
        }
    }
    @IBAction func submitAction(_ sender: Any) {
        ridesListArr.removeAll()
        txtFld.resignFirstResponder()
        let num = Int(txtFld.text ?? "0") ?? 0
        let alert = UIAlertController(title: "Alert", message: "Please Enter number in between 1 to 100", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            switch action.style{
            case .default:
                print("default")
                
            case .cancel:
                print("cancel")
                
            case .destructive:
                print("destructive")
            }
            self.txtFld.text = ""

        }))
//        if txtFld.text == "0" || txtFld.text == "" {
//
//            self.present(alert, animated: true, completion: nil)
//
//        }
//        else{
            if 1...100 ~= num {
                getRidesList()
            }
            else{
                self.present(alert, animated: true, completion: nil)
            }
            
            
        //}
    }
    
//    func dropShadow() {
//        layer.masksToBounds = false
//        layer.shadowColor = UIColor.black.cgColor
//        layer.shadowOpacity = 0.5
//        layer.shadowOffset = CGSize(width: -1, height: 1)
//        layer.shadowRadius = 1
//        layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
//        layer.shouldRasterize = true
//        layer.rasterizationScale = UIScreen.main.scale
//    }
    
    //MARK: - ApI Caling
    func getRidesList()
    {
        let parameters : [String:Any] = [:]
        APICallingViewModel.getRidesList(api:"random_vehicle/?\(txtFld.text ?? "0")&size=20", parameters: parameters) { [self] (responce) in
            // print("response",responce as Any)
            if responce != nil{
                print(responce)
               let rides = responce
                ridesListArr = rides ?? []
                sortView.isHidden = false
                vehicleTblView.reloadData()
                
            }
        }
    }
    
    //MARK: - TextField Delegate Methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtFld.resignFirstResponder()
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txtFld {
            if range.location == 3 { return false }
        }
        return true
    }
    
    //MARK: - Tableview Delegate Methods

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ridesListArr.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "VehicleTableViewCell", for: indexPath) as! VehicleTableViewCell
        if sortType == "vin"
        {
            cell.vinLbl.text = "Vin : \(ridesListArr[indexPath.row].vin ?? "")"
        }
        if sortType == "car Type"
        {
            cell.vinLbl.text = "Car Type : \(ridesListArr[indexPath.row].car_type ?? "")"
        }
        cell.modelLbl.text = "Make & Model : \(ridesListArr[indexPath.row].make_and_model ?? "")"

        cell.selectionStyle = .none
        cell.bgvieew.layer.cornerRadius = 8
        cell.bgvieew.layer.shadowColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1).cgColor
        cell.bgvieew.layer.shadowOpacity = 0.5
        cell.bgvieew.layer.shadowOffset = .zero
        cell.bgvieew.layer.shadowRadius = 5
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let navVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        navVC.rideDetails = ridesListArr[indexPath.row]
       
        self.navigationController?.pushViewController(navVC, animated: true)

    }
    
}

