//
//  CustomCollectionViewCell.swift
//  pagination-collectionview
//
//  Created by Hendy Christianto on 26/04/18.
//  Copyright © 2018 Hendy Christianto. All rights reserved.
//

import Foundation
import UIKit


class CustomCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var vinLbl: UILabel!
    @IBOutlet weak var modelLbl: UILabel!
    @IBOutlet weak var colorLbl: UILabel!
    @IBOutlet weak var carTypeLbl: UILabel!
    static func getSize() -> CGSize {
        return CGSize(width: UIScreen.main.bounds.width-20, height: 165)
    }
    
    static func reuseIdentifier() -> String {
        return "CustomCollectionViewCell"
    }
}
